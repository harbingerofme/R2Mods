﻿Disables the forward movement on MUL-T's saw.

Mod made on request. 

### Installation: 
Place the dll in your Bepinex/Plugins folder.


### Multiplayer:
Not tested.

## Changelog:
- 1.0.0 Release!