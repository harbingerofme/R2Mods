﻿Halves the time it takes for a medkit stack to pop.
Can be configured to have different values.

Mod made on request. 

### Installation: 
Place the dll in your Bepinex/Plugins folder.


### Multiplayer:
Not tested, slight effort have been made to sync it across clients in multiplayer. Let me know if you do test it.

## Changelog:
- 1.0.0 Release!