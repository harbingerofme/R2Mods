﻿Prevents the triple shop terminals from coming up with three question marks.
Also makes a slight effort to prevent those same terminals from rolling the same item three times.

Full R2API.utils dependency, need it for reflection. This means that on a game update, this mod will be broken until R2API is updated.

### Installation: 
Place in your Bepinex/Plugins folder.

### Multiplayer
* Does not break the game if host has installed and client doesn't.

## Changelog:
- 1.1.0 Fixed a bug where every terminal was rerolled. Oops!
- 1.0.0 Release!