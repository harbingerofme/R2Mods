﻿Adds the amount of times your life was saved by One Shot Protection to the endscreen.

Uses AssetPlus now for language loading.

###Installation: 
Place as a folder in the bepinex folder, you know, like all other mods.

##Changelog:
- `0.3.0` Changelog now in newest first order. Uses AssetPlus now. Makes better checks for the protection count.
- `0.2.1` hotfix for potential userprofile corruption.
- `0.1.0` initial release

