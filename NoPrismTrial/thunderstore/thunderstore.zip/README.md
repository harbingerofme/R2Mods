Adds the console command "grantprismunlocks".

Unlocks the Harvester's Scythe and the Slicing Winds for Mercenary.